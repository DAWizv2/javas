/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.warehouse;
import java.sql.*;
import java.util.Scanner;
/**
 *
 * @author 2402394
 */
public class UserInsert {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the Name of The Product You wish To insert in the Database: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter the ID of The Product You wish To insert in the Database: ");
        int itemID = scanner.nextInt();
        
        System.out.print("Enter the Quantity of The Product You wish To insert in the Database: ");
        int itemQT = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter the Location of The Product You wish To insert in the Database: ");
        String itemLO = scanner.nextLine();
        
        try{
            Connection conn = DriverManager.getConnection("jdbc:sqlite:warehouse.db");
            
            String insertQuery = "INSERT INTO items (name, itemID,itemQt,ItemLocation) VALUES (?,?,?,?)";
            PreparedStatement pstmt = conn.prepareStatement(insertQuery);
            pstmt.setString(1,name);
            pstmt.setInt(2,itemID);
            pstmt.setInt(3,itemQT);
            pstmt.setString(4, itemLO);
            pstmt.executeUpdate();
            
            System.out.println("Sucessfull");
            pstmt.close();
            conn.close();
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
