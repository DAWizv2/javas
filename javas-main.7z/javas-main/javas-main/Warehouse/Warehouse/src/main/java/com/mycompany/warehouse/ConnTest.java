package com.mycompany.warehouse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Statement;
import java.sql.ResultSet;

/*package com.mycompany.warehouse;*/
public class ConnTest {
    public static void main(String[] args) {
        Connection connection = null;
        String url = "jdbc:sqlite:warehouse.db"; 

        // Establishing the connection
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(url);
            System.out.println("Connection Sucess");
            
            
        }catch (SQLException e) {
            // Print the exception message
            System.out.println("Error: " + e.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConnTest.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (connection != null) {
                try {
                   Statement statement = connection.createStatement();
                   ResultSet resultSet = statement.executeQuery("SELECT * FROM items");
                   System.out.println("Item Data:");
                   System.out.println("ID, Name, Quantity, Location");
                   while (resultSet.next()) {
                    System.out.println(
                       resultSet.getInt("itemID")+
                       resultSet.getString("name")+
                       resultSet.getInt("itemQT")+
                       resultSet.getString("itemLO"));
                   }
                   resultSet.close();
                   statement.close();
                   connection.close();
                } catch (SQLException e) {
                }
            }
        }
    }
}