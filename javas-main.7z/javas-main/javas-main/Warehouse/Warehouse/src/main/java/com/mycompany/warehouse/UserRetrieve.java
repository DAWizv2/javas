/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.sql.*;
/**
 *
 * @author dawiz
 */
public class UserRetrieve {
    public static Connection getConnection() {
        String url = "jdbc:sqlite:warehouse.db";
    
        try {
            System.out.println("Connected to database");
            return DriverManager.getConnection(url);

        }catch (SQLException e) {
            System.out.println("Failed to connect to database");
            e.printStackTrace();
            return null;
        }
    }
}
    
public static void main(String[] args) {
    Connection conn = UserRetrieve.getConnection();
    if (conn != null) {
        System.out.println("Connected to database");
} else{
    System.out.println("Connection failed");
}
    
}