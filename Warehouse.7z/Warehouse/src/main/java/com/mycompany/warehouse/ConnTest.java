package com.mycompany.warehouse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/*package com.mycompany.warehouse;*/
public class ConnTest {
    public static void main(String[] args) {
        Connection connection = null;
        String url = "C:\\Users\\2402394\\.m2\\repository\\org\\xerial\\sqlite-jdbc\\3.49.1.0\\sqlite-jdbc-3.49.1.0.jar"; 

        // Establishing the connection
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(url);
            System.out.println("Connection Sucess");
            
            
        }catch (SQLException e) {
            // Print the exception message
            System.out.println("Error: " + e.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConnTest.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(ConnTest.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("Connection closed");
            }
        }
    }
}