/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.warehouse;

/**
 *
 * @author 2402394
 */
public class Warehouse {

}
